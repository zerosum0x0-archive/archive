# Heresy's Gate

Dynamically generate a stub for any Zw/Nt function in kernel mode, even if it is not exported.

Code: https://github.com/zerosum0x0/heresy/blob/master/heresy/heresy/scrape.c

# Work  Out

Ring 0 to Ring 3 via Worker Factories

Code: https://github.com/zerosum0x0/heresy/blob/master/heresy/heresy/inject.c

# Full Writeup

https://zerosum0x0.blogspot.com/2020/06/heresys-gate-kernel-zwntdll-scraping.html
