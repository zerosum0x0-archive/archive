// this file is not really meant to be used going forward
// It is simply here for compatibility with traditional reflective injection

#ifdef REFLECTIVEDLLINJECTION_VIA_LOADREMOTELIBRARYR
#include "zeroload/zeroload.c"
#endif