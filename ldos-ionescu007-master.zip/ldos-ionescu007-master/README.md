# ldos-ionescu007
Fanged version of Alex Ionescu's tweetable Windows DoS universal PoC

Reference: https://twitter.com/aionescu/status/991696016716922880

No root cause analysis has been performed by me. After hint, PoC now uses non loop method.
