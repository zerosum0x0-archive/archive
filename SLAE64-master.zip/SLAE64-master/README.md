SLAE64
======
x64 Linux Shellcode

http://zerosum0x0.blogspot.com/2014/12/thoughts-on-slae64-certification.html

SLAE64 - 1360
