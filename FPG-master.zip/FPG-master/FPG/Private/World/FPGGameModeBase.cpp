// Copyright (c) 2017 - zerosum0x0

#include "FPGGameModeBase.h"

void AFPGGameModeBase::BeginPlay()
{
	Super::BeginPlay();
}
