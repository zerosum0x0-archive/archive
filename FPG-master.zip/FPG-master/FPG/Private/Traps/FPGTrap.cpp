// Copyright (c) 2017 - zerosum0x0

#include "FPGTrap.h"


// Sets default values
AFPGTrap::AFPGTrap()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AFPGTrap::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AFPGTrap::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

