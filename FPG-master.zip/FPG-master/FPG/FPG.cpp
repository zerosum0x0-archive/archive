// Copyright (c) 2017 - zerosum0x0

#include "FPG.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, FPG, "FPG" );
