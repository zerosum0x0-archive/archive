# LoadLibrary() and GetProcAddress() Replacement Functions
LoadLibrary() and GetProcAddress() replacement functions for x86, x64, and ARM; with handling for forward exports.

Similar to shellcode, this searches the PEB for procedure addresses.
