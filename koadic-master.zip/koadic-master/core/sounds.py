sounds = {
#'ON': 'data/bin/sounds/on.mp3',
'SUCCESS': ['data/bin/sounds/wicked_sick.mp3', 'data/bin/sounds/holyshit.mp3'],
#'FAIL': 'data/bin/sounds/fail.mp3',
'STAGED': 'data/bin/sounds/pwned.mp3',
'KILL': 'data/bin/sounds/killing_spree.mp3',
'STAGER': 'data/bin/sounds/firstblood.mp3'
}