# puppetstrings
Hitch a free ride to Ring 0 on Windows. Why exploit 0-days when you can exploit kn0wn-days?

https://zerosum0x0.blogspot.com/2017/07/puppet-strings-dirty-secret-for-free.html

![General Overview](https://1.bp.blogspot.com/-DweBJ0suaFA/WVho52FXQ7I/AAAAAAAAAlE/umAddjHO2TIwM999FtX0uREBSCpMzz5TwCLcBGAs/s1600/kn0wn.PNG)

![Example](https://2.bp.blogspot.com/-suSs9TBVoLo/WVhlRy3d2LI/AAAAAAAAAko/TDJC4extoe8XWCijaCogibqqC2-RDRlUgCPcBGAYYCw/s1600/puppetcapcom.PNG)

You will need to obtain a copy of capcom.sys. Some code borrowed from https://github.com/tandasat/ExploitCapcom
