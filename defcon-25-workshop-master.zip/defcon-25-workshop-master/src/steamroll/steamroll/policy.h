#pragma once

_Success_(return) BOOL __fastcall CheckLockouts(void);