/* stdafx.obj will contain the pre-compiled type information */

#include "stdafx.h"
